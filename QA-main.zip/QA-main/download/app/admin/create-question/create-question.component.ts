import { Component, OnInit, Input } from '@angular/core';
import {FormControl, FormGroup, FormBuilder, FormArray, Validators} from '@angular/forms';
import { HttpClient } from "@angular/common/http";
import {Observable} from 'rxjs';
import { QUESTIONS } from "./../../service/questions"

@Component({
  selector: 'app-create-question',
  templateUrl: './create-question.component.html',
  styleUrls: ['./create-question.component.css']
})
export class CreateQuestionComponent implements OnInit {
  questions: any = [];
  email!: FormControl;
  questionText!: FormControl;
  createQuestionForm!: FormGroup;
  defaultLogin = {
    email:'dini@gmail.com',
    password:'123456789'
  };
  constructor(
    private fb: FormBuilder,
    private httpClient: HttpClient
    ) {
      this.createQuestionForm = this.fb.group(
        {
          questiontext: [null, [Validators.required]],          
        }
      )
  }
  
  ngOnInit(){
    this.email = new FormControl("",Validators.required);
    //this.questionText = new FormControl(this.defaultLogin.email,[Validators.required]);
    this.createQuestionForm = this.fb.group({
        questiontext: [null, [Validators.required]],
        //questionText: this.fb.array([this.createQuestionOption()],Validators.required),
        options: this.fb.array([this.createOption()],Validators.required)
      })

      this.httpClient.get("assets/questions.json").subscribe(data =>{
        console.log(data);
        this.questions = data;
      })
  }

  createQuestions() {
    if(this.createQuestionForm.status == 'VALID'){
      console.log(this.createQuestionForm.value);
    }
  }

  

  createOption():FormGroup{
    return this.fb.group({
      name:[null,Validators.required],
      correct:[null,Validators.required]
    })
  }

  get options():FormArray{
    return <FormArray> this.createQuestionForm.get('options');
  }

  addOption() {
    this.options.push(this.createOption());
  }

  //clone fields
  createQuestionOption():FormGroup{
    return this.fb.group({
      questiontext:[null,Validators.required],
      options:[null,Validators.required]
    })
  }
  get questiontext():FormArray{
    return <FormArray> this.createQuestionForm.get('');
  }

  addQuestion() {
    this.questiontext.push(this.createQuestionOption());
  }

}
